﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DisasterReliefApp.Data;
using DisasterReliefApp.Models;

namespace DisasterReliefApp.Controllers
{
    public class DisasterReportsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DisasterReportsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: DisasterReports
        public async Task<IActionResult> Index()
        {
            return View(await _context.DisasterReports.ToListAsync());
        }

        // GET: DisasterReports/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var disasterReport = await _context.DisasterReports
                .FirstOrDefaultAsync(m => m.Id == id);
            if (disasterReport == null)
            {
                return NotFound();
            }

            return View(disasterReport);
        }

        // GET: DisasterReports/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: DisasterReports/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Title,Location,Description,Severity,ReportedAt,ReportedBy")] DisasterReport disasterReport)
        {
            if (ModelState.IsValid)
            {
                _context.Add(disasterReport);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(disasterReport);
        }

        // GET: DisasterReports/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var disasterReport = await _context.DisasterReports.FindAsync(id);
            if (disasterReport == null)
            {
                return NotFound();
            }
            return View(disasterReport);
        }

        // POST: DisasterReports/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Title,Location,Description,Severity,ReportedAt,ReportedBy")] DisasterReport disasterReport)
        {
            if (id != disasterReport.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(disasterReport);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DisasterReportExists(disasterReport.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(disasterReport);
        }

        // GET: DisasterReports/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var disasterReport = await _context.DisasterReports
                .FirstOrDefaultAsync(m => m.Id == id);
            if (disasterReport == null)
            {
                return NotFound();
            }

            return View(disasterReport);
        }

        // POST: DisasterReports/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var disasterReport = await _context.DisasterReports.FindAsync(id);
            if (disasterReport != null)
            {
                _context.DisasterReports.Remove(disasterReport);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool DisasterReportExists(int id)
        {
            return _context.DisasterReports.Any(e => e.Id == id);
        }
    }
}
