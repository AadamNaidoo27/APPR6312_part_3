﻿using System.ComponentModel.DataAnnotations;

namespace DisasterReliefApp.Models
{
    public class DisasterReport
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Title is required")]
        public string Title { get; set; }

        [Required(ErrorMessage = "Location is required")]
        public string Location { get; set; }

        [Required(ErrorMessage = "Description is required")]
        public string Description { get; set; }

        [Required(ErrorMessage = "Severity is required")]
        public string Severity { get; set; } = "Medium";

        public DateTime ReportedAt { get; set; } = DateTime.Now;

        public string ReportedBy { get; set; }
    }
}
