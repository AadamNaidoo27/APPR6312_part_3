﻿using System.ComponentModel.DataAnnotations;

namespace DisasterReliefApp.Models
{
    public class Donation
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Donor name is required")]
        public string DonorName { get; set; }

        [Required(ErrorMessage = "Item name is required")]
        public string ItemName { get; set; }

        [Required(ErrorMessage = "Category is required")]
        public string Category { get; set; }

        [Required(ErrorMessage = "Quantity is required")]
        [Range(1, 10000, ErrorMessage = "Quantity must be at least 1")]
        public int Quantity { get; set; }

        public DateTime DonatedAt { get; set; } = DateTime.Now;
    }
}
