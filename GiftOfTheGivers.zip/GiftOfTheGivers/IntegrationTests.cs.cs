﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace GiftOfTheGivers.Tests
{
    [TestClass]
    public class IntegrationTests
    {
        [TestMethod]
        public void GetAllProjects_ShouldReturnData()
        {
            var projects = new List<string> { "Flood Relief", "Food Drive" };
            Assert.IsTrue(projects.Count > 0);
        }
    }
}
