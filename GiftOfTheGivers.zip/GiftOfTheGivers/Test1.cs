﻿namespace GiftOfTheGivers.Tests
{
    [TestClass]
    public class DonationTests
    {
        [TestMethod]
        public void TotalDonation_ShouldReturnCorrectAmount()
        {
            int donation1 = 100;
            int donation2 = 200;
            int total = donation1 + donation2;
            Assert.AreEqual(300, total);
        }
    }
}
